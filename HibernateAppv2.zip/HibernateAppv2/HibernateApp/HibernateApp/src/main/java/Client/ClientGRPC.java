package Client;

import DTO.DTOForUser;
import Services.UsersService;
import com.example.grpc.UserServiceGrpc;
import com.example.grpc.UserServiceOuterClass;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class ClientGRPC {

    public static void main(String[] args) {

        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
        EntityManager entityManager = entityManagerFactory.createEntityManager();
        EntityTransaction transaction = entityManager.getTransaction();

        ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8080").usePlaintext().build();

        UserServiceGrpc.UserServiceBlockingStub stub = UserServiceGrpc.newBlockingStub(channel);

        UserServiceOuterClass.UserRequest request = UserServiceOuterClass.UserRequest.newBuilder().setLogin("Log1").build();

        UserServiceOuterClass.UserResponse response = stub.add(request);

        DTOForUser dtoForUser = new DTOForUser();
        dtoForUser.setLogin(request.getLogin());

        UsersService usersService = new UsersService();
        usersService.addUser(dtoForUser);


        System.out.println(response);

        channel.shutdownNow();
    }
}
