package DTO;

import lombok.Data;

@Data
public class DTOForPosts {
    int id;
    String posts;
    int idUser;
    int idTag;
}
