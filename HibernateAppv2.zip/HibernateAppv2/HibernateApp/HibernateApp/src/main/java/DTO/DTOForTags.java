package DTO;

import lombok.Data;

@Data
public class DTOForTags {
    int id;
    String name;
}
