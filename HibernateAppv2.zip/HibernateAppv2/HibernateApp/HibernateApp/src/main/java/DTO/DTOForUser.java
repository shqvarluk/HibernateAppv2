package DTO;

import lombok.Data;

@Data
public class DTOForUser {
    int id;
    String login;
}
