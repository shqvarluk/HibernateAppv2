package Server;


import com.example.grpc.UserServiceGrpc;
import com.example.grpc.UserServiceOuterClass;
import io.grpc.stub.StreamObserver;

public class UserServiceImpl extends UserServiceGrpc.UserServiceImplBase {

    @Override
    public void add(UserServiceOuterClass.UserRequest request, StreamObserver<UserServiceOuterClass.UserResponse> responseObserver){
        System.out.println(request);

        UserServiceOuterClass.UserResponse response = UserServiceOuterClass.UserResponse.newBuilder().setResult("Server add user " + request.getLogin()).build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
